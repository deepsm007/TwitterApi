Start a command prompt in this directory and run the following command :

*****************************************************************************
*									    *	
*	java -jar socialmedia-0.0.1-SNAPSHOT-jar-with-dependencies.jar      *
*									    *	
*									    *
*****************************************************************************

Steps to use the packager for different twitter account:

1. Open the twitter4j.properties file with notepad
2. Edit the consumer key, consumer Secret, access token, access token secret, user and password
3. Save the file and run the jar